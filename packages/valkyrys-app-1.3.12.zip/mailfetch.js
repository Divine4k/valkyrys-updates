// Fetching purchase orders from e-mail (Settings › Connections). Plain Node, no Electron: app-main.js passes in what it needs, so it is testable on its own
// (tools/test_mailfetch.mjs, against a fake IMAP server).
//
// Accounts (Gmail, WP, any IMAP server) are kept in <data folder>/mail.json; the password only encrypted (encrypt/decrypt from app-main.js = Electron safeStorage,
// Windows DPAPI). Every few minutes the app looks in the mailbox, READ-ONLY (EXAMINE + BODY.PEEK: nothing is marked read, moved or deleted), for mails
// whose subject is "Inkooporder PO-######" with the PO PDF attached, and saves that PDF into the purchase-order folder, unless a file of that name is
// already there. Every check compares the PO mails of the last LOOKBACK_DAYS days with the folder (by PO number), so a PO missing from the folder is
// fetched again; only POs deleted through the app (Documents › delete) or ignored ("Negeren") are skipped for good (mail.json `skip`, PO numbers).
"use strict";
const fs = require("fs"), path = require("path"), net = require("net"), tls = require("tls"), crypto = require("crypto");

const PROVIDERS = { gmail: { host: "imap.gmail.com", port: 993 }, wp: { host: "imap.wp.pl", port: 993 } };
const LOOKBACK_DAYS = 30, EVERY_MS = 5 * 60 * 1000, FIRST_AFTER_MS = 0, MAX_PER_RUN = 300, TIMEOUT_MS = 45000;
const SUBJECT_RE = /inkooporder\b[^\n]*?\bPO[-\s]?(\d{3,})/i;
const PO_FILE_RE = /\bPO[-_\s]?(\d{3,})\b/i;

// ------------------------------------------------------------------ a small IMAP client: just what is needed here (LOGIN, LIST, EXAMINE, UID SEARCH/FETCH)
class Imap {
  constructor(sock) {
    this.sock = sock; this.buf = Buffer.alloc(0); this.parts = []; this.lits = []; this.n = 0; this.cur = null; this.cont = null; this.closed = null;
    this.greeting = new Promise((res, rej) => { this.greet = { res, rej }; });
    sock.on("data", (d) => { this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d; try { this.pump(); } catch (e) { this.fail(e); } });
    sock.on("error", (e) => this.fail(e));
    sock.on("close", () => this.fail(Object.assign(new Error("connection closed"), { code: "ECONNRESET" })));
    sock.setTimeout(TIMEOUT_MS, () => { this.fail(Object.assign(new Error("timeout"), { code: "ETIMEDOUT" })); sock.destroy(); });
  }
  static open({ host, port, plain }) {
    return new Promise((res, rej) => {
      const sock = plain ? net.connect({ host, port }) : tls.connect({ host, port, servername: net.isIP(host) ? undefined : host });
      const c = new Imap(sock);
      c.greeting.then(() => res(c), rej);
    });
  }
  fail(e) {
    if (this.closed) return; this.closed = e;
    if (this.greet) { this.greet.rej(e); this.greet = null; }
    if (this.cur) { this.cur.rej(e); this.cur = null; }
    if (this.cont) { this.cont.rej(e); this.cont = null; }
  }
  // a response is one line, or a line ending in {n} followed by n bytes and more of the same line; literals are kept apart as Buffers
  pump() {
    for (;;) {
      const i = this.buf.indexOf("\r\n"); if (i < 0) return;
      const line = this.buf.subarray(0, i).toString("latin1"), m = /\{(\d+)\}$/.exec(line);
      if (m) {
        const n = Number(m[1]); if (this.buf.length < i + 2 + n) return;
        this.parts.push(line); this.lits.push(Buffer.from(this.buf.subarray(i + 2, i + 2 + n))); this.buf = this.buf.subarray(i + 2 + n); continue;
      }
      this.buf = this.buf.subarray(i + 2);
      const text = this.parts.join("") + line, lits = this.lits; this.parts = []; this.lits = [];
      this.onResp(text, lits);
    }
  }
  onResp(text, lits) {
    if (this.greet) { const g = this.greet; this.greet = null; if (/^\* (OK|PREAUTH)/i.test(text)) g.res(); else g.rej(Object.assign(new Error(text), { code: "EPROTO" })); return; }
    if (text.startsWith("+")) { if (this.cont) { const c = this.cont; this.cont = null; c.res(); } return; }
    if (text.startsWith("* ")) { if (this.cur) this.cur.untagged.push({ text, lits }); return; }
    const m = /^(A\d+) (OK|NO|BAD)\b ?(.*)$/i.exec(text);
    if (m && this.cur && this.cur.tag === m[1]) { const c = this.cur; this.cur = null; c.res({ status: m[2].toUpperCase(), text: m[3], untagged: c.untagged }); }
  }
  // parts: strings, and { lit: string } for values sent as a literal (anything a quoted string cannot carry)
  async cmd(...parts) {
    if (this.closed) throw this.closed;
    const tag = "A" + ++this.n;
    const done = new Promise((res, rej) => { this.cur = { tag, untagged: [], res, rej }; });
    let line = tag + " ";
    for (const p of parts) {
      if (typeof p === "string") { line += p; continue; }
      const b = Buffer.isBuffer(p.lit) ? p.lit : Buffer.from(p.lit, "utf8");
      const go = new Promise((res, rej) => { this.cont = { res, rej }; });
      this.sock.write(line + "{" + b.length + "}\r\n", "latin1"); await go;
      this.sock.write(b); line = "";
    }
    this.sock.write(line + "\r\n", "latin1");
    return done;
  }
  async ok(...parts) { const r = await this.cmd(...parts); if (r.status !== "OK") throw Object.assign(new Error(r.text || r.status), { code: "EIMAP", imap: r }); return r; }
  close() { try { if (!this.closed) { this.sock.write("A" + ++this.n + " LOGOUT\r\n"); this.sock.end(); } } catch (e) {} this.closed = this.closed || new Error("closed"); setTimeout(() => { try { this.sock.destroy(); } catch (e) {} }, 2000).unref(); }
}
// a string as an IMAP argument: quoted when it can be, else a literal
const arg = (s) => (/^[\x20-\x7e]*$/.test(s) ? '"' + s.replace(/(["\\])/g, "\\$1") + '"' : { lit: s });

// ------------------------------------------------------------------ reading a mail (MIME): headers, the parts, attachments with their names
const unfold = (h) => h.replace(/\r?\n[ \t]+/g, " ");
function headers(text) {
  const out = {};
  for (const l of unfold(text).split(/\r?\n/)) { const i = l.indexOf(":"); if (i > 0) { const k = l.slice(0, i).trim().toLowerCase(); if (!(k in out)) out[k] = l.slice(i + 1).trim(); } }
  return out;
}
const charsetDecode = (buf, cs) => { try { return new TextDecoder(String(cs || "utf-8").toLowerCase().replace(/^(us-ascii|ascii)$/, "utf-8")).decode(buf); } catch (e) { return buf.toString("latin1"); } };
const qp = (s, underscore) => { const out = []; s = underscore ? s.replace(/_/g, " ") : s.replace(/=\r?\n/g, ""); for (let i = 0; i < s.length; i++) { const c = s[i]; if (c === "=" && /^[0-9a-f]{2}$/i.test(s.slice(i + 1, i + 3))) { out.push(parseInt(s.slice(i + 1, i + 3), 16)); i += 2; } else out.push(s.charCodeAt(i) & 255); } return Buffer.from(out); };
/** "=?UTF-8?B?...?=" words in a header */
const words = (s) => String(s || "").replace(/\?=\s+=\?/g, "?==?").replace(/=\?([^?]+)\?([bq])\?([^?]*)\?=/gi, (m, cs, enc, t) => charsetDecode(enc.toLowerCase() === "b" ? Buffer.from(t, "base64") : qp(t, true), cs.replace(/\*.*$/, "")));
/** `type; a=b; c="d"` -> { value, params }, with RFC 2231 names (name*=utf-8''x, name*0=, name*1=) */
function params(v) {
  const s = String(v || ""), semi = s.indexOf(";"), value = (semi < 0 ? s : s.slice(0, semi)).trim().toLowerCase(), raw = {}, re = /;\s*([^=\s;]+)\s*=\s*("((?:[^"\\]|\\.)*)"|[^;]*)/g;
  let m; while ((m = re.exec(s))) raw[m[1].toLowerCase()] = m[3] !== undefined ? m[3].replace(/\\(.)/g, "$1") : m[2].trim();
  const p = {}, star = {};
  for (const [k, val] of Object.entries(raw)) {
    const r = /^([^*]+)\*(?:(\d+)\*?|)$/.exec(k);
    if (r && (k.endsWith("*") || /\*\d+$/.test(k))) { (star[r[1]] = star[r[1]] || []).push({ i: Number(r[2] || 0), v: val, enc: k.endsWith("*") }); } else p[k] = words(val);
  }
  for (const [k, list] of Object.entries(star)) {
    list.sort((a, b) => a.i - b.i); let cs = "utf-8", bytes = [];
    list.forEach((x, n) => { let v = x.v; if (x.enc) { if (n === 0) { const q = /^([^']*)'[^']*'(.*)$/.exec(v); if (q) { cs = q[1] || cs; v = q[2]; } } bytes.push(Buffer.from(v.replace(/%([0-9a-f]{2})/gi, (mm, h) => String.fromCharCode(parseInt(h, 16))), "latin1")); } else bytes.push(Buffer.from(v, "latin1")); });
    p[k] = charsetDecode(Buffer.concat(bytes), cs);
  }
  return { value, params: p };
}
/** a whole mail (Buffer) -> { subject, from, attachments: [{ name, type, data }] } */
function parseMail(raw) {
  const atts = [];
  const walk = (s, depth) => {
    const i = s.search(/\r?\n\r?\n/), h = headers(i < 0 ? s : s.slice(0, i)), body = i < 0 ? "" : s.slice(i).replace(/^\r?\n\r?\n/, "");
    const ct = params(h["content-type"] || "text/plain"), cd = params(h["content-disposition"] || "");
    if (ct.value.startsWith("multipart/") && ct.params.boundary && depth < 8) {
      const b = "--" + ct.params.boundary, chunks = body.split(new RegExp("(?:^|\\r?\\n)" + b.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?:--)?[ \\t]*(?:\\r?\\n|$)"));
      for (const c of chunks.slice(1)) if (c.trim()) walk(c, depth + 1);
      return { h };
    }
    const name = cd.params.filename || ct.params.name || "";
    if (name || cd.value === "attachment" || ct.value === "application/pdf") {
      const enc = String(h["content-transfer-encoding"] || "").trim().toLowerCase();
      const data = enc === "base64" ? Buffer.from(body.replace(/[^A-Za-z0-9+/=]/g, ""), "base64") : enc === "quoted-printable" ? qp(body) : Buffer.from(body, "latin1");
      atts.push({ name, type: ct.value, data });
    }
    return { h };
  };
  const top = walk(raw.toString("latin1"), 0).h;
  return { subject: words(top.subject || "").trim(), from: words(top.from || "").trim(), attachments: atts };
}
/** the PO PDFs in a mail, if it is a purchase-order mail ("Inkooporder PO-######" with the PDF): [{ name, data }] */
function poFiles(mail) {
  const sm = SUBJECT_RE.exec(mail.subject || ""); if (!sm) return [];
  const out = [];
  for (const a of mail.attachments) {
    const pdf = a.data.subarray(0, 1024).includes("%PDF"); if (!pdf) continue;
    const base = path.basename(String(a.name || "").replace(/\\/g, "/"));
    let name = PO_FILE_RE.test(base) && /\.pdf$/i.test(base) ? base : "PO-" + sm[1] + ".pdf";
    name = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "").replace(/^\.+/, "").trim() || "PO-" + sm[1] + ".pdf";
    if (!out.some((o) => o.name.toLowerCase() === name.toLowerCase())) out.push({ name, data: a.data });
  }
  return out;
}

// ------------------------------------------------------------------ one check of one account
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const imapDate = (d) => `${d.getDate()}-${MON[d.getMonth()]}-${d.getFullYear()}`;
const errCode = (e) => {
  const t = String((e && e.message) || "");
  if (e && e.code === "EAUTH") return /application-specific|app.?password|webloginrequired/i.test(t) ? "apppass" : "auth";
  if (e && ["ENOTFOUND", "EAI_AGAIN", "ECONNREFUSED", "ENETUNREACH", "EHOSTUNREACH", "ETIMEDOUT", "ECONNRESET"].includes(e.code)) return "net";
  if (e && /CERT|SSL|TLS/i.test(String(e.code || "") + t)) return "tls";
  return "other";
};
/** the mailbox to look in: Gmail's "All Mail" (so mails moved away from the inbox by a filter are found too), else INBOX */
async function pickBox(c, acc) {
  if (acc.provider !== "gmail") return "INBOX";
  try {
    const r = await c.cmd('LIST "" "*"');
    for (const u of r.untagged) { const m = /^\* LIST \(([^)]*)\) (?:"[^"]*"|NIL) (.+)$/i.exec(u.text); if (m && /\\All\b/i.test(m[1])) return u.lits.length ? u.lits[0].toString("utf8") : m[2]; }
  } catch (e) {}
  return "INBOX";
}
const boxArg = (b) => (/^".*"$/.test(b) ? b : arg(b));

async function login(acc, pass, plain) {
  let c;
  try { c = await Imap.open({ host: acc.host, port: acc.port, plain }); } catch (e) { throw Object.assign(e, { kind: errCode(e) }); }
  const lr = await c.cmd("LOGIN ", arg(acc.user), " ", arg(pass)).catch((e) => { c.close(); throw Object.assign(e, { kind: errCode(e) }); });
  if (lr.status !== "OK") { c.close(); const e = Object.assign(new Error(lr.text || "login failed"), { code: "EAUTH" }); throw Object.assign(e, { kind: errCode(e) }); }
  return c;
}
async function examine(c, box) {
  const ex = await c.ok("EXAMINE ", boxArg(box)); // read-only: nothing gets marked as read
  let uv = 0, next = 0;
  for (const u of ex.untagged) { let m; if ((m = /\[UIDVALIDITY (\d+)\]/i.exec(u.text))) uv = Number(m[1]); if ((m = /\[UIDNEXT (\d+)\]/i.exec(u.text))) next = Number(m[1]); }
  return { uv, next };
}
async function fetchMail(c, uid) {
  const fr = await c.ok("UID FETCH " + uid + " (BODY.PEEK[])");
  const lit = fr.untagged.find((u) => u.lits.length && /FETCH/i.test(u.text));
  return lit ? parseMail(lit.lits[0]) : null;
}

/** the PO number in a subject or file name ("Inkooporder PO-008248" / "PO-008248.pdf" -> "8248"; leading zeros do not count) */
const poNum = (s, re = PO_FILE_RE) => { const m = re.exec(String(s || "")); return m ? String(Number(m[1])) : ""; };
const subjectNum = (s) => poNum(s, SUBJECT_RE);

/** log in and compare the PO mails of the last LOOKBACK_DAYS days with the folder. PDFs of POs that are not there (have(number) false) and not
 *  skipped are saved (save), or with `hold` only noted (asked first: hold(name, uid, uidValidity)). Only their headers are read first; whole mails
 *  only for the missing ones. st = { box } of this account (kept). Returns { saved: [names], held: [names], inMail: number of POs in the mail } */
async function checkAccount(acc, pass, st, { have, skip = () => false, save, hold, plain, now = new Date() }) {
  const c = await login(acc, pass, plain);
  try {
    const box = st.box || (st.box = await pickBox(c, acc));
    const { uv } = await examine(c, box);
    const since = new Date(now.getTime() - LOOKBACK_DAYS * 86400000);
    const sr = await c.ok("UID SEARCH SINCE " + imapDate(since) + ' SUBJECT "Inkooporder"');
    let uids = [];
    for (const u of sr.untagged) { const m = /^\* SEARCH\b(.*)$/i.exec(u.text); if (m) uids.push(...m[1].trim().split(/\s+/).filter(Boolean).map(Number)); }
    uids = [...new Set(uids)].filter((u) => u > 0).sort((a, b) => b - a).slice(0, MAX_PER_RUN); // newest first
    // the subjects, all in one go: which PO number is in which mail
    const byNum = new Map();
    if (uids.length) {
      const hr = await c.ok("UID FETCH " + uids.join(",") + " (UID BODY.PEEK[HEADER.FIELDS (SUBJECT)])");
      for (const u of hr.untagged) {
        const um = /\bUID (\d+)/i.exec(u.text); if (!um || !u.lits.length) continue;
        const n = subjectNum(words(headers(u.lits[0].toString("latin1")).subject || ""));
        if (n && !byNum.has(n)) byNum.set(n, Number(um[1])); // the newest mail of a PO number
      }
    }
    const saved = [], held = [];
    for (const [n, uid] of [...byNum].sort((a, b) => Number(a[0]) - Number(b[0]))) { // oldest PO first
      if (have(n) || skip(n)) continue;
      const mail = await fetchMail(c, uid);
      for (const f of mail ? poFiles(mail) : []) {
        if (have(poNum(f.name) || n)) continue;
        if (hold) { await hold(f.name, uid, uv); held.push(f.name); } else if (await save(f.name, f.data)) saved.push(f.name);
      }
    }
    st.uidValidity = uv; delete st.lastUid;
    return { saved, held, inMail: byNum.size };
  } finally { c.close(); }
}

// ------------------------------------------------------------------ sending: a small SMTP client (implicit TLS, port 465) and the mail itself (MIME)
const SMTP = { gmail: { host: "smtp.gmail.com", port: 465 }, wp: { host: "smtp.wp.pl", port: 465 } };
const smtpOf = (acc) => acc.smtp || SMTP[acc.provider] || { host: String(acc.host || "").replace(/^imap\./i, "smtp."), port: 465 };
const MAX_ATTACH = 18 * 1024 * 1024; // what Gmail and most others still take after base64 (25 MB)
class Smtp {
  constructor(sock) {
    this.sock = sock; this.buf = ""; this.lines = []; this.wait = null; this.closed = null;
    sock.on("data", (d) => { this.buf += d.toString("latin1"); this.pump(); });
    sock.on("error", (e) => this.fail(e));
    sock.on("close", () => this.fail(Object.assign(new Error("connection closed"), { code: "ECONNRESET" })));
    sock.setTimeout(TIMEOUT_MS, () => { this.fail(Object.assign(new Error("timeout"), { code: "ETIMEDOUT" })); sock.destroy(); });
  }
  static open({ host, port, plain }) {
    return new Promise((res, rej) => {
      const sock = plain ? net.connect({ host, port }) : tls.connect({ host, port, servername: net.isIP(host) ? undefined : host });
      const c = new Smtp(sock); c.reply().then((r) => (r.code === 220 ? res(c) : rej(Object.assign(new Error(r.text), { code: "EPROTO" }))), rej);
    });
  }
  fail(e) { if (this.closed) return; this.closed = e; if (this.wait) { const w = this.wait; this.wait = null; w.rej(e); } }
  // a reply is one or more lines "250-..." ending with "250 ..."
  pump() {
    for (;;) {
      const i = this.buf.indexOf("\r\n"); if (i < 0) return;
      const line = this.buf.slice(0, i); this.buf = this.buf.slice(i + 2); this.lines.push(line);
      if (/^\d{3}(?: |$)/.test(line) && this.wait) { const w = this.wait, ls = this.lines; this.wait = null; this.lines = []; w.res({ code: Number(line.slice(0, 3)), text: ls.map((l) => l.slice(4)).join(" ") }); }
    }
  }
  reply() { if (this.closed) return Promise.reject(this.closed); const p = new Promise((res, rej) => { this.wait = { res, rej }; }); this.pump(); return p; }
  async cmd(line, ok = [250]) {
    if (this.closed) throw this.closed;
    this.sock.write(line + "\r\n", "latin1");
    const r = await this.reply();
    if (!ok.includes(r.code)) throw Object.assign(new Error(r.text || String(r.code)), { code: "ESMTP", smtp: r.code });
    return r;
  }
  close() { try { if (!this.closed) { this.sock.write("QUIT\r\n"); this.sock.end(); } } catch (e) {} this.closed = this.closed || new Error("closed"); setTimeout(() => { try { this.sock.destroy(); } catch (e) {} }, 2000).unref(); }
}
const b64lines = (buf) => buf.toString("base64").replace(/.{76}(?=.)/g, "$&\r\n");
const encWord = (s) => (/^[\x20-\x7e]*$/.test(s) ? s : "=?UTF-8?B?" + Buffer.from(s, "utf8").toString("base64") + "?=");
const asciiName = (n) => n.normalize("NFKD").replace(/[^\x20-\x7e]/g, "").replace(/["\\]/g, "") || "file.pdf";
/** the whole mail: { from: { name, addr }, to: [addr], subject, text, attachments: [{ name, bytes, type }] } -> Buffer */
function buildMail({ from, to, subject, text, attachments = [], now = new Date() }) {
  const b = "----=_valkyrys_" + crypto.randomBytes(8).toString("hex");
  const head = [
    "From: " + (from.name ? encWord(from.name.replace(/[<>"]/g, "")) + " " : "") + "<" + from.addr + ">", "To: " + to.join(", "), "Subject: " + encWord(subject || ""),
    "Date: " + now.toUTCString().replace("GMT", "+0000"), "Message-ID: <" + crypto.randomBytes(12).toString("hex") + "@valkyrys.app>", "MIME-Version: 1.0",
    `Content-Type: multipart/mixed; boundary="${b}"`, "", "--" + b, "Content-Type: text/plain; charset=utf-8", "Content-Transfer-Encoding: base64", "", b64lines(Buffer.from(String(text || "").replace(/\r?\n/g, "\r\n"), "utf8"))];
  for (const a of attachments) {
    const n = String(a.name || "file.pdf");
    head.push("--" + b, `Content-Type: ${a.type || "application/pdf"}; name="${asciiName(n)}"`, "Content-Transfer-Encoding: base64",
      `Content-Disposition: attachment; filename="${asciiName(n)}"; filename*=utf-8''${encodeURIComponent(n)}`, "", b64lines(Buffer.from(a.bytes)));
  }
  head.push("--" + b + "--", "");
  return Buffer.from(head.join("\r\n"), "utf8");
}
const EMAIL_RE = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[^\s@<>(),;:"]+$/;
/** send one mail through an account: SMTP (log in, MAIL FROM, RCPT TO each, DATA) */
async function smtpSend(acc, pass, mailBuf, to, { plain }) {
  const w = smtpOf(acc); let c;
  try { c = await Smtp.open({ host: w.host, port: w.port, plain }); } catch (e) { throw Object.assign(e, { kind: errCode(e) }); }
  try {
    await c.cmd("EHLO valkyrys.app");
    try { await c.cmd("AUTH PLAIN " + Buffer.from("\0" + acc.user + "\0" + pass, "utf8").toString("base64"), [235]); }
    catch (e) { if (e.code === "ESMTP") { const x = Object.assign(new Error(e.message), { code: "EAUTH" }); throw Object.assign(x, { kind: errCode(x) }); } throw e; }
    await c.cmd("MAIL FROM:<" + acc.user + ">");
    for (const r of to) { try { await c.cmd("RCPT TO:<" + r + ">", [250, 251]); } catch (e) { throw Object.assign(e, { kind: "rcpt", rcpt: r }); } }
    await c.cmd("DATA", [354]);
    c.sock.write(mailBuf); // base64 bodies and plain headers: no line starts with "."
    await c.cmd("\r\n.", [250]);
  } catch (e) { if (!e.kind) e.kind = errCode(e); throw e; } finally { c.close(); }
}
/** a copy in the account's "Sent" folder (Gmail does this by itself): IMAP APPEND into the \Sent mailbox, or a usual name */
async function saveSent(acc, pass, mailBuf, { plain }) {
  const c = await login(acc, pass, plain);
  try {
    let box = "";
    const r = await c.cmd('LIST "" "*"');
    for (const u of r.untagged) { const m = /^\* LIST \(([^)]*)\) (?:"[^"]*"|NIL) (.+)$/i.exec(u.text); if (m && /\\Sent\b/i.test(m[1])) { box = u.lits.length ? u.lits[0].toString("utf8") : m[2]; break; } }
    if (!box) { const names = r.untagged.map((u) => { const m = /^\* LIST \([^)]*\) (?:"[^"]*"|NIL) (.+)$/i.exec(u.text); return m ? m[1].replace(/^"|"$/g, "") : ""; }); box = ["Sent", "Wysłane", "INBOX.Sent", "Sent Items", "Verzonden"].find((n) => names.includes(n)) || ""; }
    if (!box) return false;
    await c.ok("APPEND ", boxArg(box), " (\\Seen) ", { lit: mailBuf });
    return true;
  } finally { c.close(); }
}

// ------------------------------------------------------------------ the accounts, the timer, and what the page sees
// mail.json = { accounts: [...], mode: "ask" (default) | "auto", unseen: [names fetched that the page has not shown yet], pending: [{ key, acc, uid, uv, name, at }] (found, asked first),
//              skip: [PO numbers deleted through the app or ignored: never fetched again] }
function create({ dataDir, poFolder, encrypt, decrypt, canRun = () => true, send = () => {}, plain = false }) {
  const file = path.join(dataDir, "mail.json");
  const arr = (x) => (Array.isArray(x) ? x : []);
  const read = () => { let d = {}; try { d = JSON.parse(fs.readFileSync(file, "utf8")) || {}; } catch (e) {} return { ...d, accounts: arr(d.accounts), mode: d.mode === "auto" ? "auto" : "ask", unseen: arr(d.unseen), pending: arr(d.pending), skip: arr(d.skip) }; };
  const write = (d) => { fs.mkdirSync(dataDir, { recursive: true }); const t = file + ".tmp"; fs.writeFileSync(t, JSON.stringify(d, null, 2)); fs.renameSync(t, file); };
  const change = (fn) => { const d = read(); const r = fn(d); write(d); return r; };
  const busy = new Set(); let timer = null, chain = Promise.resolve(), queued = 0;
  const serial = (fn) => { queued++; const r = chain.then(fn, fn).finally(() => { queued--; }); chain = r.catch(() => {}); return r; };
  const pub = (a) => ({ id: a.id, provider: a.provider, user: a.user, host: a.host, port: a.port, enabled: a.enabled !== false, lastCheck: a.lastCheck || 0, lastOk: a.lastOk || 0,
    error: a.error || "", found: a.found || 0, inMail: a.inMail ?? null, lastFiles: a.lastFiles || [], busy: busy.has(a.id) });
  const state = () => { const d = read(); return { mode: d.mode, accounts: d.accounts.map(pub), unseen: d.unseen, pending: d.pending.map((p) => ({ key: p.key, name: p.name, account: p.acc, at: p.at || 0 })) }; };
  const emit = (extra) => { try { send(Object.assign(state(), extra || {})); } catch (e) {} };
  const where = (provider, host) => { if (PROVIDERS[provider]) return PROVIDERS[provider]; const m = /^\s*([^\s:/]+)(?::(\d+))?\s*$/.exec(String(host || "")); return m ? { host: m[1].toLowerCase(), port: Number(m[2] || 993) } : null; };
  const folderOk = () => { const f = poFolder(); return f && fs.existsSync(f) ? f : ""; };
  const uniq = (list) => { const seen = new Set(); return list.filter((n) => { const k = String(n).toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; }); };

  // the PO folder: which file names and PO numbers are there already (in it or a subfolder, any case), and saving into it without ever overwriting
  const names = (root) => {
    const out = new Set(), nums = new Set(); let n = 0;
    const walk = (d, depth) => { let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; } for (const e of es) { if (++n > 20000) return; if (e.isDirectory()) { if (depth < 2) walk(path.join(d, e.name), depth + 1); } else { out.add(e.name.toLowerCase()); if (/\.pdf$/i.test(e.name)) { const k = poNum(e.name); if (k) nums.add(k); } } } };
    walk(root, 0); return { has: (name) => out.has(String(name).toLowerCase()), hasNum: (k) => nums.has(k), add: (name) => { out.add(name.toLowerCase()); const k = poNum(name); if (k) nums.add(k); }, del: (name) => out.delete(name.toLowerCase()) };
  };
  const saver = (folder, have) => async (n, bytes) => { // true when written (false: a file of that name was already there)
    if (have.has(n)) return false;
    have.add(n);
    try { fs.writeFileSync(path.join(folder, n), bytes, { flag: "wx" }); return true; } catch (e) { if (e.code === "EEXIST") return false; have.del(n); throw e; }
  };
  const keepAcc = (d, a) => { const i = d.accounts.findIndex((x) => x.id === a.id); if (i >= 0) Object.assign(d.accounts[i], { state: a.state, lastCheck: a.lastCheck, lastOk: a.lastOk, error: a.error, found: a.found, lastFiles: a.lastFiles, inMail: a.inMail }); };

  async function runOne(acc, folder, have, ask, skip) {
    busy.add(acc.id); emit();
    const st = acc.state || (acc.state = {}), held = [];
    try {
      const save = saver(folder, have);
      const r = await checkAccount(acc, decrypt(acc.pass), st, { plain, have: (k) => have.hasNum(k), skip: (k) => skip.has(k), save,
        hold: ask ? (n, uid, uv) => { held.push({ key: `${acc.id}:${uv}:${uid}:${n.toLowerCase()}`, acc: acc.id, uid, uv, name: n, at: Date.now() }); } : null });
      Object.assign(acc, { lastCheck: Date.now(), lastOk: Date.now(), error: "", inMail: r.inMail });
      if (r.saved.length) { acc.found = (acc.found || 0) + r.saved.length; acc.lastFiles = r.saved.slice(-20); }
      return { saved: r.saved, held };
    } catch (e) {
      Object.assign(acc, { lastCheck: Date.now(), error: e.kind || errCode(e) });
      return { saved: [], held: [] };
    } finally { busy.delete(acc.id); }
  }

  /** check every switched-on account (or just one id). Fetched files go to the page as { saved: [...] }, files found when asking first as { found: [...] } */
  const check = (id) => serial(async () => {
    const folder = folderOk(), data = read(), list = data.accounts.filter((a) => (id ? a.id === id : a.enabled !== false));
    if (!list.length) return { saved: [], found: [] };
    if (!folder) { change((d) => { for (const a of d.accounts) if (list.some((x) => x.id === a.id)) Object.assign(a, { lastCheck: Date.now(), error: "nofolder" }); }); emit(); return { saved: [], found: [], error: "nofolder" }; }
    const have = names(folder), saved = [], found = [], ask = data.mode === "ask", skip = new Set(data.skip.map(String));
    for (const p of data.pending) skip.add(poNum(p.name)); // already offered: not again
    for (const a of list) {
      const r = await runOne(a, folder, have, ask, skip);
      r.held.forEach((h) => skip.add(poNum(h.name)));
      saved.push(...r.saved);
      change((d) => {
        keepAcc(d, a);
        if (r.saved.length) d.unseen = uniq([...d.unseen, ...r.saved]).slice(-50);
        for (const h of r.held) if (!d.pending.some((p) => poNum(p.name) === poNum(h.name))) { d.pending.push(h); found.push(h.name); }
      });
    }
    change((d) => { d.pending = d.pending.filter((p) => !have.hasNum(poNum(p.name))); }); // found earlier, but the file is in the folder by now
    emit(saved.length || found.length ? { saved, found } : null);
    return { saved, found };
  });

  /** download POs that were found while asking first (all, or the given keys) */
  const download = (keys) => serial(async () => {
    const folder = folderOk(); if (!folder) return { saved: [], error: "nofolder" };
    const data = read(), want = data.pending.filter((p) => !keys || keys.includes(p.key)), have = names(folder), save = saver(folder, have), done = new Set(), saved = [];
    let error = "";
    for (const accId of [...new Set(want.map((p) => p.acc))]) {
      const acc = data.accounts.find((a) => a.id === accId), mine = want.filter((p) => p.acc === accId);
      if (!acc) { mine.forEach((p) => done.add(p.key)); continue; }
      let c = null; busy.add(acc.id); emit();
      try {
        c = await login(acc, decrypt(acc.pass), plain);
        const { uv } = await examine(c, (acc.state && acc.state.box) || "INBOX");
        for (const p of mine) {
          if (have.hasNum(poNum(p.name)) || p.uv !== uv) { done.add(p.key); continue; } // already there, or the mailbox was renumbered: nothing to fetch
          const mail = await fetchMail(c, p.uid), files = mail ? poFiles(mail) : [];
          const f = files.find((x) => x.name.toLowerCase() === p.name.toLowerCase()) || files[0];
          if (f && (await save(p.name, f.data))) saved.push(p.name);
          done.add(p.key); // fetched, or the mail is gone
        }
        acc.error = "";
      } catch (e) { error = acc.error = e.kind || errCode(e); }
      finally { busy.delete(acc.id); if (c) c.close(); }
      change((d) => { const x = d.accounts.find((y) => y.id === acc.id); if (x) { x.error = acc.error; if (saved.length) x.found = (x.found || 0) + mine.filter((p) => saved.includes(p.name)).length; } });
    }
    change((d) => { d.pending = d.pending.filter((p) => !done.has(p.key)); });
    emit(saved.length ? { saved, downloaded: true } : null);
    return { saved, error };
  });
  /** found POs not wanted: forgotten (they are not offered again) */
  function ignore(keys) { change((d) => { const out = d.pending.filter((p) => !keys || keys.includes(p.key)); d.skip = [...new Set([...d.skip, ...out.map((p) => poNum(p.name)).filter(Boolean)])].slice(-2000); d.pending = d.pending.filter((p) => !out.includes(p)); }); emit(); return true; }
  /** a PO file deleted through the app: its PO is never fetched again */
  function forget(name) { const k = poNum(path.basename(String(name || ""))); if (k) change((d) => { if (!d.skip.includes(k)) d.skip = [...d.skip, k].slice(-2000); d.pending = d.pending.filter((p) => poNum(p.name) !== k); }); return true; }
  /** the page has shown the fetched POs */
  function seen() { const d = read(); if (d.unseen.length) { d.unseen = []; write(d); emit(); } return true; }
  function setMode(m) { change((d) => { d.mode = m === "auto" ? "auto" : "ask"; }); emit(); return true; }

  /** add an account: the login is tried first, and it is only kept when that works. { ok, account } or { error } */
  async function add({ provider, user, pass, host }) {
    provider = PROVIDERS[provider] ? provider : "imap";
    user = String(user || "").trim(); pass = String(pass || "");
    const w = where(provider, host);
    if (!user || !pass) return { error: "missing" };
    if (!w) return { error: "host" };
    const acc = { id: crypto.randomBytes(6).toString("hex"), provider, user, host: w.host, port: w.port, enabled: true };
    if (read().accounts.some((a) => a.user.toLowerCase() === user.toLowerCase() && a.host === acc.host)) return { error: "dup" };
    try { (await login(acc, pass, plain)).close(); } catch (e) { return { error: e.kind || errCode(e), detail: String(e.message || "").slice(0, 200) }; }
    acc.pass = encrypt(pass); acc.added = Date.now();
    change((d) => { d.accounts.push(acc); }); emit();
    setTimeout(() => check(acc.id).catch(() => {}), 50);
    return { ok: true, account: pub(acc) };
  }
  /** send invoices: { account, to: [addr], subject, text, fromName, attachments: [{ name, bytes }] } -> { ok } or { error, rcpt } */
  async function sendMail(o) {
    const d = read(), acc = d.accounts.find((a) => a.id === o.account) || d.accounts.find((a) => a.enabled !== false);
    if (!acc) return { error: "noaccount" };
    const to = [...new Set((o.to || []).map((x) => String(x).trim()).filter(Boolean))];
    if (!to.length || to.some((x) => !EMAIL_RE.test(x))) return { error: "to", rcpt: to.find((x) => !EMAIL_RE.test(x)) || "" };
    const atts = (o.attachments || []).filter((a) => a && a.bytes && a.bytes.length);
    if (atts.reduce((n, a) => n + a.bytes.length, 0) > MAX_ATTACH) return { error: "size" };
    const mailBuf = buildMail({ from: { name: String(o.fromName || ""), addr: acc.user }, to, subject: String(o.subject || ""), text: String(o.text || ""), attachments: atts });
    let pass; try { pass = decrypt(acc.pass); } catch (e) { return { error: "auth" }; }
    busy.add(acc.id); emit();
    try { await smtpSend(acc, pass, mailBuf, to, { plain }); }
    catch (e) { return { error: e.kind || errCode(e), rcpt: e.rcpt || "", detail: String(e.message || "").slice(0, 200) }; }
    finally { busy.delete(acc.id); emit(); }
    let copy = acc.provider === "gmail"; // Gmail keeps a copy in Sent by itself
    if (!copy) { try { copy = await saveSent(acc, pass, mailBuf, { plain }); } catch (e) { copy = false; } }
    return { ok: true, copy, from: acc.user };
  }
  function remove(id) { change((d) => { d.accounts = d.accounts.filter((a) => a.id !== id); d.pending = d.pending.filter((p) => p.acc !== id); }); emit(); return true; }
  function setEnabled(id, on) { let a; change((d) => { a = d.accounts.find((x) => x.id === id); if (a) { a.enabled = !!on; if (on) a.error = ""; } }); emit(); if (a && on) setTimeout(() => check(id).catch(() => {}), 50); return !!a; }
  /** checks: right at the start (while the splash plays, also before the PIN is entered: it only reads the mail and saves into the PO folder),
   *  then every EVERY_MS once the app is unlocked. Returns the first check (resolves, never fails). */
  function auto(firstMs = FIRST_AFTER_MS) {
    if (timer) return Promise.resolve();
    const tick = () => { if (canRun() && !queued) check().catch(() => {}); };
    timer = setInterval(tick, EVERY_MS); timer.unref?.();
    return new Promise((res) => { setTimeout(() => { check().catch(() => {}).then(res, res); }, firstMs).unref?.(); });
  }
  function stop() { if (timer) clearInterval(timer); timer = null; }
  return { state, add, remove, setEnabled, setMode, check, download, ignore, forget, seen, auto, stop, send: sendMail };
}

module.exports = { create, poNum, buildMail, smtpOf, Smtp, parseMail, poFiles, checkAccount, PROVIDERS, Imap, imapDate, errCode, params, words };
